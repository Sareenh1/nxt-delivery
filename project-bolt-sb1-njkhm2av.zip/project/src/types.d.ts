// Add Window interface augmentation for Leaflet
interface Window {
  L: any;
}